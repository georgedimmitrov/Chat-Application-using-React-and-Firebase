import React from 'react';

function ChatInputBox() {
  return (
    <div className="ChatInputBox">
      <input className="ChatInput" placeholder="Message #general" />
    </div>
  );
}

export default ChatInputBox;
